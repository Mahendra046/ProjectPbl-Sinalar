<?php

namespace App\Models;

class Divisi extends Model
{
    
}