<?php

namespace App\Models;
use App\models\Traits\Attributes\PembelianAttributes;

class Pembelian extends Model
{
    use PembelianAttributes;
}